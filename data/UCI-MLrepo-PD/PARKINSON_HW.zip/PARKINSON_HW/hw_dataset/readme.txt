Dataset is delimited as CSV values as follows;

X ; Y; Z; Pressure; GripAngle; Timestamp; Test ID

----------------
Test ID: 
0: Static Spiral Test ( Draw on the given spiral pattern)
1: Dynamic Spiral Test ( Spiral pattern will blink in a certain time, so subjects need to continue on their draw)
2: Circular Motion Test (Subjectd draw circles around the red point)